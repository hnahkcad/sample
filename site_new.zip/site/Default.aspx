<%@ Page Language="C#" %>
<!DOCTYPE html>
<html>
<body>
    <script>window.location = "Login.aspx";</script>
</body>
</html>