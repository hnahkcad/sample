-- ========================================
-- File: redteam.sql
-- Purpose: Tạo database và bảng Users cho dự án RedTeam WebApp
-- ========================================

-- 1. Tạo database
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'RedTeamDB')
BEGIN
    CREATE DATABASE RedTeamDB;
END
GO

-- 2. Sử dụng database vừa tạo
USE RedTeamDB;
GO

-- 3. Tạo bảng Users
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = N'Users')
BEGIN
    CREATE TABLE Users
    (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Username NVARCHAR(50) NOT NULL UNIQUE,
        Password NVARCHAR(255) NOT NULL,
        CreatedAt DATETIME DEFAULT GETDATE()
    );
END
GO

-- 4. Optional: Thêm admin test account
INSERT INTO Users (Username, Password)
VALUES ('admin', 'admin123'); -- Lưu ý: password chưa hash
GO
