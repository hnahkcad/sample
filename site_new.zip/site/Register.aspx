<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Register.aspx.cs" Inherits="WebApp.Register" %>
<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link href="css/bootstrap.min.css" rel="stylesheet" />
<script src="js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-dark text-white">
<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-4">
<div class="card bg-secondary p-4 rounded-4 shadow">
<h3 class="text-center">Create Account</h3>
<form id="form1" runat="server">
<div class="mb-3">
<label>Username</label>
<asp:TextBox ID="txtUser" CssClass="form-control" runat="server" />
</div>
<div class="mb-3">
<label>Password</label>
<asp:TextBox ID="txtPass" TextMode="Password" CssClass="form-control" runat="server" />
</div>
<asp:Button ID="btnRegister" Text="Register" CssClass="btn btn-danger w-100" runat="server" OnClick="btnRegister_Click" />
<br /><br />
<asp:Label ID="lblMsg" runat="server" CssClass="text-warning" />
</form>
</div>
</div>
</div>
</div>
</body>
</html>