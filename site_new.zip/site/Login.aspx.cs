using System;
using System.Data.SqlClient;


namespace WebApp
{
public partial class Login : System.Web.UI.Page
{
protected void btnLogin_Click(object sender, EventArgs e)
{
using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString))
{
conn.Open();
SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username=@u AND Password=@p", conn);
cmd.Parameters.AddWithValue("@u", txtUser.Text);
cmd.Parameters.AddWithValue("@p", txtPass.Text);


int count = (int)cmd.ExecuteScalar();
if (count > 0)
{
Session["user"] = txtUser.Text;
Response.Redirect("Dashboard.aspx");
}
else
{
lblMsg.Text = "Invalid username or password";
}
}
}
protected void btnRegisterInline_Click(object sender, EventArgs e)
{
    using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString))
    {
        conn.Open();
        SqlCommand cmd = new SqlCommand("INSERT INTO Users (Username, Password) VALUES (@u, @p)", conn);
        cmd.Parameters.AddWithValue("@u", txtNewUser.Text);
        cmd.Parameters.AddWithValue("@p", txtNewPass.Text);

        try
        {
            cmd.ExecuteNonQuery();
            lblMsg.Text = "Account created successfully!";
        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error: " + ex.Message;
        }
    }
}
}
}