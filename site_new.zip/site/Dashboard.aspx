<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Dashboard.aspx.cs" Inherits="WebApp.Dashboard" %>
<!DOCTYPE html>
<html>
<head>
<title>CyRadar Dashboard</title>
<link href="css/bootstrap.min.css" rel="stylesheet" />
<script src="js/bootstrap.bundle.min.js"></script>
<style>
.red-header { background:#8B0000; }
</style>
</head>
<body class="bg-dark text-white">
<nav class="navbar red-header px-3">
<span class="navbar-brand text-white">RedTeam Control Panel</span>
<a href="Logout.aspx" class="btn btn-outline-light">Logout</a>
</nav>


<div class="container mt-4">
<h2>Welcome, <asp:Label ID="lblUser" runat="server" />!</h2>


<div class="row mt-4">
<div class="col-md-4">
<div class="card bg-secondary p-3 rounded-4 shadow">
<h4>Recon Tools</h4>
<ul>
<li>Network Scanner</li>
<li>Port Mapper</li>
<li>Subdomain Enum</li>
</ul>
</div>
</div>


<div class="col-md-4">
<div class="card bg-secondary p-3 rounded-4 shadow">
<h4>Payload Management</h4>
<ul>
<li>Upload Payload</li>
<li>Generate Stagers</li>
<li>Session Logs</li>
</ul>
</div>
</div>


<div class="col-md-4">
<div class="card bg-secondary p-3 rounded-4 shadow">
<h4>System Info</h4>
<ul>
<li>Server Time</li>
<li>IIS Version</li>
<li>SQL Status</li>
</ul>
</div>
</div>
</div>
</div>
</body>
</html>