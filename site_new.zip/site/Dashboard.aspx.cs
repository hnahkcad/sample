using System;


namespace WebApp
{
public partial class Dashboard : System.Web.UI.Page
{
protected void Page_Load(object sender, EventArgs e)
{
if (!IsPostBack)
{
if (Session["user"] == null)
Response.Redirect("Login.aspx");


lblUser.Text = Session["user"].ToString();
}
}
}
}