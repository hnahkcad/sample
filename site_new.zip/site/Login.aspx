<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Login.aspx.cs" Inherits="WebApp.Login" %>

<!DOCTYPE html>

<html>
<head>
    <title>CyRadar</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" />
<script src="js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-dark text-white">
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-4">
      <div class="card bg-secondary p-4 rounded-4 shadow">
        <h3 class="text-center">RedTeam Login</h3>
        <form id="form1" runat="server">
          <!-- Login Section -->
          <div class="mb-3">
            <label>Username</label>
            <asp:TextBox ID="txtUser" CssClass="form-control" runat="server" />
          </div>
          <div class="mb-3">
            <label>Password</label>
            <asp:TextBox ID="txtPass" TextMode="Password" CssClass="form-control" runat="server" />
          </div>
          <asp:Button ID="btnLogin" Text="Login" CssClass="btn btn-danger w-100" runat="server" OnClick="btnLogin_Click" />


      <!-- Register Toggle -->
      <div class="text-center mt-3">
        <a href="#" class="text-warning" data-bs-toggle="collapse" data-bs-target="#registerBox">Create new account</a>
      </div>

      <!-- Register Section -->
      <div id="registerBox" class="collapse mt-4">
        <h5 class="text-center">Register</h5>
        <div class="mb-2">
          <label>New Username</label>
          <asp:TextBox ID="txtNewUser" CssClass="form-control" runat="server" />
        </div>
        <div class="mb-2">
          <label>New Password</label>
          <asp:TextBox ID="txtNewPass" TextMode="Password" CssClass="form-control" runat="server" />
        </div>
        <asp:Button ID="btnRegisterInline" Text="Register" CssClass="btn btn-warning w-100" runat="server" OnClick="btnRegisterInline_Click" />
      </div>

      <br />
      <asp:Label ID="lblMsg" runat="server" CssClass="text-warning" />
    </form>
  </div>
</div>


  </div>
</div>
    <link href="css/bootstrap.min.css" rel="stylesheet" />
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
