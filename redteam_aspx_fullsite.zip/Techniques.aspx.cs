using System;
public partial class _Techniques : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
}
