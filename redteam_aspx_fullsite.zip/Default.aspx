<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="_Default" %>
<!DOCTYPE html>
<html>
<head>
    <title>Red Team Info</title>
    <link rel="stylesheet" href="assets/style.css" />
</head>
<body>
    <img src="assets/logo.png" style="height:80px;" />
    <h1>Trang chủ</h1>
    <p>Thông tin tổng quan về Red Team.</p>
    <nav>
        <a href="Default.aspx">Home</a> |
        <a href="About.aspx">Về Red Team</a> |
        <a href="Techniques.aspx">Kỹ thuật</a>
    </nav>
</body>
</html>
