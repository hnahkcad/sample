<%@ Page Language="C#" AutoEventWireup="true" CodeFile="About.aspx.cs" Inherits="_About" %>
<!DOCTYPE html>
<html>
<head>
    <title>About Red Team</title>
    <link rel="stylesheet" href="assets/style.css" />
</head>
<body>
    <img src="assets/logo.png" style="height:80px;" />
    <h1>Red Team là gì?</h1>
    <p>Red Team mô phỏng tấn công có kiểm soát để đánh giá an ninh.</p>
</body>
</html>
