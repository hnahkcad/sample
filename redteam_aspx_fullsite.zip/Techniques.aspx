<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Techniques.aspx.cs" Inherits="_Techniques" %>
<!DOCTYPE html>
<html>
<head>
    <title>Kỹ thuật</title>
    <link rel="stylesheet" href="assets/style.css" />
</head>
<body>
    <img src="assets/logo.png" style="height:80px;" />
    <h1>Kỹ thuật Red Team (khái quát)</h1>
    <ul>
        <li>OSINT – thu thập thông tin hợp pháp.</li>
        <li>Mô phỏng phishing (không hướng dẫn thực thi).</li>
        <li>Kiểm tra cấu hình mạng nội bộ.</li>
        <li>Mô phỏng MITRE ATT&CK.</li>
    </ul>
</body>
</html>
