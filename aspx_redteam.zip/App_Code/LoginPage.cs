using System;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;

public class LoginPage : Page {
    public string Message = "";
    protected void Page_Load(object sender, EventArgs e) {
        if (IsPostBack) {
            var u = Request["user"];
            var p = Request["pass"];
            using(var conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RedTeamDb"].ConnectionString)) {
                conn.Open();
                var cmd = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username=@u AND Password=@p", conn);
                cmd.Parameters.AddWithValue("@u", u);
                cmd.Parameters.AddWithValue("@p", p);
                int n = (int)cmd.ExecuteScalar();
                Message = n>0 ? "Login OK" : "Invalid";
            }
        }
    }
}
