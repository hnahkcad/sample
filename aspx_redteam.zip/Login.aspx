<%@ Page Language="C#" Inherits="LoginPage" %>
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
<form method="post">
User: <input name="user"/><br/>
Pass: <input type="password" name="pass"/><br/>
<input type="submit" value="Login"/>
</form>
<%= Message %>
</body>
</html>
