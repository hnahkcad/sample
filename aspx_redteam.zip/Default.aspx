<%@ Page Language="C#" %>
<!DOCTYPE html>
<html>
<head><title>RedTeam Site</title></head>
<body>
<h1>Welcome to RedTeam Static ASPX Site</h1>
<a href="Login.aspx">Login</a>
</body>
</html>
